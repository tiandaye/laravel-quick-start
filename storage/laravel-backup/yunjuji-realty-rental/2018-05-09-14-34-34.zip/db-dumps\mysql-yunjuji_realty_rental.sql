
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分类名称',
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类图片',
  `parent_id` int(11) DEFAULT '0' COMMENT '上级分类',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  `order` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_name_index` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'1',NULL,NULL,1,0,NULL,'2018-05-09 03:19:10','2018-05-09 03:19:10',NULL),(2,'123',NULL,NULL,1,0,NULL,'2018-05-09 03:22:05','2018-05-09 03:22:05',NULL),(3,'123456',NULL,NULL,1,0,NULL,'2018-05-09 03:23:15','2018-05-09 03:23:15',NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laravel_admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laravel_admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laravel_admin_menu` WRITE;
/*!40000 ALTER TABLE `laravel_admin_menu` DISABLE KEYS */;
INSERT INTO `laravel_admin_menu` VALUES (1,0,1,'Index','fa-bar-chart','/',NULL,NULL),(2,0,2,'Admin','fa-tasks','',NULL,NULL),(3,2,3,'Users','fa-users','auth/users',NULL,NULL),(4,2,4,'Roles','fa-user','auth/roles',NULL,NULL),(5,2,5,'Permission','fa-ban','auth/permissions',NULL,NULL),(6,2,6,'Menu','fa-bars','auth/menu',NULL,NULL),(7,2,7,'Operation log','fa-history','auth/logs',NULL,NULL);
/*!40000 ALTER TABLE `laravel_admin_menu` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laravel_admin_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laravel_admin_operation_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `laravel_admin_operation_log_user_id_index` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laravel_admin_operation_log` WRITE;
/*!40000 ALTER TABLE `laravel_admin_operation_log` DISABLE KEYS */;
INSERT INTO `laravel_admin_operation_log` VALUES (1,1,'admin','GET','127.0.0.1','[]','2018-05-09 01:18:45','2018-05-09 01:18:45'),(2,1,'admin','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:18:48','2018-05-09 01:18:48'),(3,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:18:50','2018-05-09 01:18:50'),(4,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:18:51','2018-05-09 01:18:51'),(5,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:18:52','2018-05-09 01:18:52'),(6,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:18:52','2018-05-09 01:18:52'),(7,1,'admin/auth/roles','GET','127.0.0.1','[]','2018-05-09 01:21:24','2018-05-09 01:21:24'),(8,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:21:26','2018-05-09 01:21:26'),(9,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:21:28','2018-05-09 01:21:28'),(10,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:21:28','2018-05-09 01:21:28'),(11,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:21:29','2018-05-09 01:21:29'),(12,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:21:31','2018-05-09 01:21:31'),(13,1,'admin/auth/users/1/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:21:34','2018-05-09 01:21:34'),(14,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:38:02','2018-05-09 01:38:02'),(15,1,'admin/auth/users','GET','127.0.0.1','[]','2018-05-09 01:38:05','2018-05-09 01:38:05'),(16,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:38:14','2018-05-09 01:38:14'),(17,1,'admin/auth/users','GET','127.0.0.1','[]','2018-05-09 01:40:11','2018-05-09 01:40:11'),(18,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:40:18','2018-05-09 01:40:18'),(19,1,'admin','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:40:21','2018-05-09 01:40:21'),(20,1,'admin','GET','127.0.0.1','[]','2018-05-09 01:45:41','2018-05-09 01:45:41'),(21,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:45:45','2018-05-09 01:45:45'),(22,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:45:46','2018-05-09 01:45:46'),(23,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:45:47','2018-05-09 01:45:47'),(24,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 01:45:47','2018-05-09 01:45:47'),(25,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:01:39','2018-05-09 02:01:39'),(26,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:01:40','2018-05-09 02:01:40'),(27,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:01:41','2018-05-09 02:01:41'),(28,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:01:42','2018-05-09 02:01:42'),(29,1,'admin','GET','127.0.0.1','[]','2018-05-09 02:53:47','2018-05-09 02:53:47'),(30,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:53:50','2018-05-09 02:53:50'),(31,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:53:51','2018-05-09 02:53:51'),(32,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:53:52','2018-05-09 02:53:52'),(33,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:53:53','2018-05-09 02:53:53'),(34,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:53:58','2018-05-09 02:53:58'),(35,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:53:59','2018-05-09 02:53:59'),(36,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:54:00','2018-05-09 02:54:00'),(37,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:54:01','2018-05-09 02:54:01'),(38,1,'admin','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 02:54:21','2018-05-09 02:54:21'),(39,1,'admin','GET','127.0.0.1','[]','2018-05-09 03:02:59','2018-05-09 03:02:59'),(40,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:03:15','2018-05-09 03:03:15'),(41,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:03:16','2018-05-09 03:03:16'),(42,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:03:17','2018-05-09 03:03:17'),(43,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:03:19','2018-05-09 03:03:19'),(44,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:03:22','2018-05-09 03:03:22'),(45,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:03:23','2018-05-09 03:03:23'),(46,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:03:24','2018-05-09 03:03:24'),(47,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:03:25','2018-05-09 03:03:25'),(48,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:04:03','2018-05-09 03:04:03'),(49,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:04:04','2018-05-09 03:04:04'),(50,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:04:05','2018-05-09 03:04:05'),(51,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:04:07','2018-05-09 03:04:07'),(52,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:10:31','2018-05-09 03:10:31'),(53,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:11:04','2018-05-09 03:11:04'),(54,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:11:07','2018-05-09 03:11:07'),(55,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:12:18','2018-05-09 03:12:18'),(56,1,'admin/mall/product/categories/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:12:21','2018-05-09 03:12:21'),(57,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:12:22','2018-05-09 03:12:22'),(58,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:18:15','2018-05-09 03:18:15'),(59,1,'admin/mall/product/categories/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:18:18','2018-05-09 03:18:18'),(60,1,'admin/mall/product/categories/create','GET','127.0.0.1','[]','2018-05-09 03:18:23','2018-05-09 03:18:23'),(61,1,'admin/mall/product/categories/create','GET','127.0.0.1','[]','2018-05-09 03:19:00','2018-05-09 03:19:00'),(62,1,'admin/mall/product/categories','POST','127.0.0.1','{\"name\":null,\"parent_id\":null,\"status\":\"1\",\"order\":\"0\",\"description\":null,\"_token\":\"POjBcAsWej84VoBLiV0cVlyxcvMecXTTW2cvNcKl\"}','2018-05-09 03:19:05','2018-05-09 03:19:05'),(63,1,'admin/mall/product/categories/create','GET','127.0.0.1','[]','2018-05-09 03:19:05','2018-05-09 03:19:05'),(64,1,'admin/mall/product/categories','POST','127.0.0.1','{\"name\":\"1\",\"parent_id\":null,\"status\":\"1\",\"order\":\"0\",\"description\":null,\"_token\":\"POjBcAsWej84VoBLiV0cVlyxcvMecXTTW2cvNcKl\"}','2018-05-09 03:19:10','2018-05-09 03:19:10'),(65,1,'admin/mall/product/categories/create','GET','127.0.0.1','[]','2018-05-09 03:19:10','2018-05-09 03:19:10'),(66,1,'admin/mall/product/categories/create','GET','127.0.0.1','[]','2018-05-09 03:21:06','2018-05-09 03:21:06'),(67,1,'admin/mall/product/categories/create','GET','127.0.0.1','[]','2018-05-09 03:21:58','2018-05-09 03:21:58'),(68,1,'admin/mall/product/categories','POST','127.0.0.1','{\"name\":null,\"parent_id\":null,\"status\":\"1\",\"order\":\"0\",\"description\":null,\"_token\":\"POjBcAsWej84VoBLiV0cVlyxcvMecXTTW2cvNcKl\"}','2018-05-09 03:22:01','2018-05-09 03:22:01'),(69,1,'admin/mall/product/categories/create','GET','127.0.0.1','[]','2018-05-09 03:22:01','2018-05-09 03:22:01'),(70,1,'admin/mall/product/categories','POST','127.0.0.1','{\"name\":\"123\",\"parent_id\":null,\"status\":\"1\",\"order\":\"0\",\"description\":null,\"_token\":\"POjBcAsWej84VoBLiV0cVlyxcvMecXTTW2cvNcKl\"}','2018-05-09 03:22:05','2018-05-09 03:22:05'),(71,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:22:06','2018-05-09 03:22:06'),(72,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:22:09','2018-05-09 03:22:09'),(73,1,'admin/mall/product/categories/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:22:17','2018-05-09 03:22:17'),(74,1,'admin/mall/product/categories/create','GET','127.0.0.1','[]','2018-05-09 03:22:44','2018-05-09 03:22:44'),(75,1,'admin/auth/users/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:22:50','2018-05-09 03:22:50'),(76,1,'admin/auth/users','POST','127.0.0.1','{\"username\":\"123456\",\"name\":\"123456\",\"password\":\"123456\",\"password_confirmation\":\"123456\",\"roles\":[null],\"permissions\":[null],\"_token\":\"POjBcAsWej84VoBLiV0cVlyxcvMecXTTW2cvNcKl\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/users\"}','2018-05-09 03:23:00','2018-05-09 03:23:00'),(77,1,'admin/auth/users','GET','127.0.0.1','[]','2018-05-09 03:23:01','2018-05-09 03:23:01'),(78,1,'admin/mall/product/categories/create','GET','127.0.0.1','[]','2018-05-09 03:23:05','2018-05-09 03:23:05'),(79,1,'admin/mall/product/categories','POST','127.0.0.1','{\"name\":\"123456\",\"parent_id\":null,\"status\":\"1\",\"order\":\"0\",\"description\":null,\"_token\":\"POjBcAsWej84VoBLiV0cVlyxcvMecXTTW2cvNcKl\"}','2018-05-09 03:23:15','2018-05-09 03:23:15'),(80,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:23:15','2018-05-09 03:23:15'),(81,1,'admin/auth/users/2/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:25:24','2018-05-09 03:25:24'),(82,1,'admin/auth/users/2','PUT','127.0.0.1','{\"username\":\"123456\",\"name\":\"123456\",\"password\":\"$2y$10$VKKBct1nhS.CR1zDg.Z6J.4uEO17WXSPXwIu\\/jw1yMG9cbheJwl.e\",\"password_confirmation\":\"$2y$10$VKKBct1nhS.CR1zDg.Z6J.4uEO17WXSPXwIu\\/jw1yMG9cbheJwl.e\",\"roles\":[null],\"permissions\":[null],\"_token\":\"POjBcAsWej84VoBLiV0cVlyxcvMecXTTW2cvNcKl\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/users\"}','2018-05-09 03:25:26','2018-05-09 03:25:26'),(83,1,'admin/auth/users','GET','127.0.0.1','[]','2018-05-09 03:25:27','2018-05-09 03:25:27'),(84,1,'admin/mall/product/categories/2/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:25:33','2018-05-09 03:25:33'),(85,1,'admin/mall/product/categories/2','PUT','127.0.0.1','{\"name\":\"123\",\"parent_id\":null,\"status\":\"1\",\"order\":\"0\",\"description\":null,\"_token\":\"POjBcAsWej84VoBLiV0cVlyxcvMecXTTW2cvNcKl\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/mall\\/product\\/categories\"}','2018-05-09 03:25:35','2018-05-09 03:25:35'),(86,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:25:36','2018-05-09 03:25:36'),(87,1,'admin/auth/users/2/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:25:50','2018-05-09 03:25:50'),(88,1,'admin/auth/users/2','PUT','127.0.0.1','{\"username\":\"123456\",\"name\":\"123456\",\"password\":\"$2y$10$VKKBct1nhS.CR1zDg.Z6J.4uEO17WXSPXwIu\\/jw1yMG9cbheJwl.e\",\"password_confirmation\":\"$2y$10$VKKBct1nhS.CR1zDg.Z6J.4uEO17WXSPXwIu\\/jw1yMG9cbheJwl.e\",\"roles\":[null],\"permissions\":[null],\"_token\":\"POjBcAsWej84VoBLiV0cVlyxcvMecXTTW2cvNcKl\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/users\"}','2018-05-09 03:25:58','2018-05-09 03:25:58'),(89,1,'admin/auth/users','GET','127.0.0.1','[]','2018-05-09 03:25:58','2018-05-09 03:25:58'),(90,1,'admin/mall/product/categories/1/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:35:11','2018-05-09 03:35:11'),(91,1,'admin/mall/product/categories/1','PUT','127.0.0.1','{\"name\":\"1\",\"parent_id\":null,\"status\":\"1\",\"order\":\"0\",\"description\":null,\"_token\":\"POjBcAsWej84VoBLiV0cVlyxcvMecXTTW2cvNcKl\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/mall\\/product\\/categories\"}','2018-05-09 03:35:14','2018-05-09 03:35:14'),(92,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:35:14','2018-05-09 03:35:14'),(93,1,'log-viewer/logs/2018-05-09/error','GET','127.0.0.1','[]','2018-05-09 03:56:31','2018-05-09 03:56:31'),(94,1,'log-viewer/logs/2018-05-09/error','GET','127.0.0.1','[]','2018-05-09 03:56:35','2018-05-09 03:56:35'),(95,1,'admin/auth/users','GET','127.0.0.1','[]','2018-05-09 03:56:37','2018-05-09 03:56:37'),(96,1,'admin/auth/users','GET','127.0.0.1','[]','2018-05-09 03:56:40','2018-05-09 03:56:40'),(97,1,'admin/mall/product/categories','GET','127.0.0.1','[]','2018-05-09 03:56:43','2018-05-09 03:56:43'),(98,1,'log-viewer/logs/2018-05-09/error','GET','127.0.0.1','[]','2018-05-09 03:56:45','2018-05-09 03:56:45'),(99,1,'log-viewer/logs/2018-05-09/error','GET','127.0.0.1','[]','2018-05-09 03:56:54','2018-05-09 03:56:54'),(100,1,'admin/log-viewer/logs/2018-05-09/error','GET','127.0.0.1','[]','2018-05-09 03:57:18','2018-05-09 03:57:18'),(101,1,'admin/log-viewer/logs/2018-05-09/error','GET','127.0.0.1','[]','2018-05-09 03:57:20','2018-05-09 03:57:20'),(102,1,'admin/log-viewer/logs/2018-05-09/error','GET','127.0.0.1','[]','2018-05-09 03:57:21','2018-05-09 03:57:21'),(103,1,'admin/log-viewer/logs/2018-05-09/error','GET','127.0.0.1','[]','2018-05-09 03:57:22','2018-05-09 03:57:22'),(104,1,'admin/log-viewer/logs/2018-05-09/error','GET','127.0.0.1','[]','2018-05-09 03:57:24','2018-05-09 03:57:24'),(105,1,'admin/auth/logout','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2018-05-09 03:57:26','2018-05-09 03:57:26'),(106,1,'admin/log-viewer','GET','127.0.0.1','[]','2018-05-09 03:59:10','2018-05-09 03:59:10'),(107,1,'admin/log-viewer/logs','GET','127.0.0.1','[]','2018-05-09 03:59:13','2018-05-09 03:59:13'),(108,1,'admin/log-viewer','GET','127.0.0.1','[]','2018-05-09 03:59:14','2018-05-09 03:59:14'),(109,1,'admin/log-viewer','GET','127.0.0.1','[]','2018-05-09 03:59:15','2018-05-09 03:59:15'),(110,1,'admin/log-viewer','GET','127.0.0.1','[]','2018-05-09 03:59:16','2018-05-09 03:59:16'),(111,1,'admin','GET','127.0.0.1','[]','2018-05-09 05:32:48','2018-05-09 05:32:48'),(112,1,'admin/log-viewer','GET','127.0.0.1','[]','2018-05-09 05:32:54','2018-05-09 05:32:54'),(113,1,'admin/auth/login','GET','127.0.0.1','[]','2018-05-09 05:33:09','2018-05-09 05:33:09'),(114,1,'admin','GET','127.0.0.1','[]','2018-05-09 05:33:09','2018-05-09 05:33:09');
/*!40000 ALTER TABLE `laravel_admin_operation_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laravel_admin_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laravel_admin_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `laravel_admin_permissions_name_unique` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laravel_admin_permissions` WRITE;
/*!40000 ALTER TABLE `laravel_admin_permissions` DISABLE KEYS */;
INSERT INTO `laravel_admin_permissions` VALUES (1,'All permission','*','','*',NULL,NULL),(2,'Dashboard','dashboard','GET','/',NULL,NULL),(3,'Login','auth.login','','/auth/login\r\n/auth/logout',NULL,NULL),(4,'User setting','auth.setting','GET,PUT','/auth/setting',NULL,NULL),(5,'Auth management','auth.management','','/auth/roles\r\n/auth/permissions\r\n/auth/menu\r\n/auth/logs',NULL,NULL);
/*!40000 ALTER TABLE `laravel_admin_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laravel_admin_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laravel_admin_role_menu` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `laravel_admin_role_menu_role_id_menu_id_index` (`role_id`,`menu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laravel_admin_role_menu` WRITE;
/*!40000 ALTER TABLE `laravel_admin_role_menu` DISABLE KEYS */;
INSERT INTO `laravel_admin_role_menu` VALUES (1,2,NULL,NULL);
/*!40000 ALTER TABLE `laravel_admin_role_menu` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laravel_admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laravel_admin_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `laravel_admin_role_permissions_role_id_permission_id_index` (`role_id`,`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laravel_admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `laravel_admin_role_permissions` DISABLE KEYS */;
INSERT INTO `laravel_admin_role_permissions` VALUES (1,1,NULL,NULL);
/*!40000 ALTER TABLE `laravel_admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laravel_admin_role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laravel_admin_role_users` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `laravel_admin_role_users_role_id_user_id_index` (`role_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laravel_admin_role_users` WRITE;
/*!40000 ALTER TABLE `laravel_admin_role_users` DISABLE KEYS */;
INSERT INTO `laravel_admin_role_users` VALUES (1,1,NULL,NULL);
/*!40000 ALTER TABLE `laravel_admin_role_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laravel_admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laravel_admin_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `laravel_admin_roles_name_unique` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laravel_admin_roles` WRITE;
/*!40000 ALTER TABLE `laravel_admin_roles` DISABLE KEYS */;
INSERT INTO `laravel_admin_roles` VALUES (1,'Administrator','administrator','2018-05-09 01:16:31','2018-05-09 01:16:31');
/*!40000 ALTER TABLE `laravel_admin_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laravel_admin_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laravel_admin_user_permissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `laravel_admin_user_permissions_user_id_permission_id_index` (`user_id`,`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laravel_admin_user_permissions` WRITE;
/*!40000 ALTER TABLE `laravel_admin_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `laravel_admin_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laravel_admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laravel_admin_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `laravel_admin_users_username_unique` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laravel_admin_users` WRITE;
/*!40000 ALTER TABLE `laravel_admin_users` DISABLE KEYS */;
INSERT INTO `laravel_admin_users` VALUES (1,'admin','$2y$10$uwTeEgBZu5Fv1.gXdy3JseraJMsg/yRv6g6WmSIm2/f75xt/KFbUO','Administrator',NULL,'9v7wk67gHFRlOMfkSYfR18nhbXFTVHCQFZAhckB6ZNG9jhR5loQW0831tdUW','2018-05-09 01:16:31','2018-05-09 01:16:31'),(2,'123456','$2y$10$VKKBct1nhS.CR1zDg.Z6J.4uEO17WXSPXwIu/jw1yMG9cbheJwl.e','123456',NULL,NULL,'2018-05-09 03:23:01','2018-05-09 03:23:01');
/*!40000 ALTER TABLE `laravel_admin_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_01_04_173148_create_admin_tables',1),(4,'2017_12_05_154534_create_categories_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

